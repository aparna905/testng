package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {
	public static WebElement element;

	public static WebElement searchField(WebDriver driver, WebDriverWait wait) {
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("search_query_top")));
		return element;

	}

	public static WebElement submitSearch_button(WebDriver driver) {
		element = driver.findElement(By.name("submit_search"));
		return element;

	}

	public static WebElement signIn(WebDriver driver, WebDriverWait wait) {
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Sign in")));
		//System.out.println(element);
		return element;

	}

}
