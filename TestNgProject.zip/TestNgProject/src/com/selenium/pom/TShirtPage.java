package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TShirtPage {
	public static WebElement element;
	public static WebElement shirtLink(WebDriver driver){
		element= driver.findElement(By.linkText("Add to cart"));
		return element;
	}

}
