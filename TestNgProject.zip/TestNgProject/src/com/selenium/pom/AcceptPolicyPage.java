package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AcceptPolicyPage {

public static WebElement element;
	
	public static WebElement acceptPolicy_button(WebDriver driver){
		element=driver.findElement(By.name("button"));
		return element;
		
	}
}
