package com.selenium.pom;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MyAccountPage {
	public static WebElement element;
	public static List<WebElement> list;
	public static WebElement personalInfo_Link(WebDriver driver, WebDriverWait wait) {
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("icon-user")));
		return element;
	}
	
	public static WebElement itemLink(WebDriver driver,WebDriverWait wait){

		element=  wait.until(ExpectedConditions.elementToBeClickable(By.tagName("a")));
		list=driver.findElements(By.tagName("a"));
		//System.out.println(list.size());
		//for(WebElement each:)
		return list.get(8);
	}
}
