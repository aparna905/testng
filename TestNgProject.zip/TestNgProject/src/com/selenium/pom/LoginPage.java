package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

	public static WebElement element;
	
	public static WebElement emailBox(WebDriver driver){
		element=driver.findElement(By.id("email_create"));		
		return element;
	}
	
	public static WebElement createAccount_button(WebDriver driver){
	element=driver.findElement(By.id("SubmitCreate"));
	return element;
	}
	
	public static WebElement loginEmail_Field(WebDriver driver){
		element=driver.findElement(By.id("email"));
		return element;
		
	}
	public static WebElement loginPassword_Field(WebDriver driver){
		element=driver.findElement(By.id("passwd"));
		return element;
		
	}
	public static WebElement submitLogin_button(WebDriver driver){
		
		element=driver.findElement(By.id("SubmitLogin"));
		return element;
		}
}
