package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CartPage {

	public static WebElement element;

	public static WebElement cartItem_Link(WebDriver driver,WebDriverWait wait) {
		element=driver.findElement(By.xpath("//div[@class='layer_cart_product_info']/span"));
		return element;
	}
}
