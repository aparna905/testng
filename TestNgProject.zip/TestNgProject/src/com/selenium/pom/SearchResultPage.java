package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SearchResultPage {
	public static WebElement element;

	public static WebElement topSellers_Link(WebDriver driver) {
		//System.out.println("here");
		element = driver.findElement(By.linkText("Women"));
		//element=(WebElement) wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.linkText("Women")));
		//System.out.println(element);
		return element;
	}
}
