package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RegistrationPage {

	public static WebElement element;
	
	
	public static WebElement titleMr_radio(WebDriver driver, WebDriverWait wait) {
		element = wait.until(ExpectedConditions.elementToBeClickable(By.id("id_gender1")));
		return element;
	}

	public static WebElement titleMrs_radio(WebDriver driver, WebDriverWait wait) {
		element = wait.until(ExpectedConditions.elementToBeClickable(By.id("id_gender2")));
		return element;
	}

	public static WebElement firstNameField(WebDriver driver) {
		element = driver.findElement(By.id("customer_firstname"));
		return element;
	}

	public static WebElement lastNameField(WebDriver driver) {
		element = driver.findElement(By.id("customer_lastname"));
		return element;
	}

	public static WebElement passwordField(WebDriver driver) {
		element = driver.findElement(By.id("passwd"));
		return element;
	}

	public static WebElement daysField(WebDriver driver) {
		element = driver.findElement(By.id("days"));
		return element;
	}

	public static WebElement monthsField(WebDriver driver) {
		element = driver.findElement(By.id("months"));
		return element;
	}

	public static WebElement yearsField(WebDriver driver) {
		element = driver.findElement(By.id("years"));
		return element;
	}

	public static WebElement newsLetter_checkBox(WebDriver driver) {
		element = driver.findElement(By.id("newsletter"));
		return element;
	}

	public static WebElement options_checkBox(WebDriver driver) {
		element = driver.findElement(By.id("optin"));
		return element;
	}
	
	public static WebElement fname_Field(WebDriver driver){
		element= driver.findElement(By.id("firstname"));
		return element;
		
	}
	
	public static WebElement lname_Field(WebDriver driver){
		element= driver.findElement(By.id("lastname"));
		return element;
		
	}
	
	public static WebElement company_Field(WebDriver driver){
		element= driver.findElement(By.id("company"));
		return element;
		
	}
	public static WebElement address1_Field(WebDriver driver){
		element= driver.findElement(By.id("address1"));
		return element;
		
	}
	
	public static WebElement address2_Field(WebDriver driver){
		element= driver.findElement(By.id("address2"));
		return element;
		
	}
	public static WebElement city_Field(WebDriver driver){
		element= driver.findElement(By.id("city"));
		return element;
		
	}
	public static WebElement state_dropdown(WebDriver driver){
		element= driver.findElement(By.id("id_state"));
		return element;
		
	}
	public static WebElement zip_field(WebDriver driver){
		element= driver.findElement(By.id("postcode"));
		return element;
	}
	public static WebElement country_dropdown(WebDriver driver){
		element= driver.findElement(By.id("id_country"));
		return element;
	}
	
	public static WebElement other_field(WebDriver driver){
		element= driver.findElement(By.id("other"));
		return element;
	}
	
	public static WebElement homeNum_field(WebDriver driver){
		element= driver.findElement(By.id("phone"));
		return element;
	}
	
	public static WebElement mobNum_field(WebDriver driver){
		element= driver.findElement(By.id("phone_mobile"));
		return element;
	}
	public static WebElement addressAlias_field(WebDriver driver){
		element= driver.findElement(By.id("alias"));
		return element;
	}
	
	public static WebElement submit_button(WebDriver driver){
		element= driver.findElement(By.id("submitAccount"));
		return element;
	}
	
}


