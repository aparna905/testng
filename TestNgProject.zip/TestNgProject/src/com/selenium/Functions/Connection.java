package com.selenium.Functions;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Parameters;

import com.selenium.base.Testbase;

/*Author:Aparna
 * Aim:Configuring TestNg
 *
 */

public class Connection extends Testbase {

	public static void openBrowser(String url) {
		// function to open a browser

		if (browser.equals("InternetExplorer")) {

			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();

			capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			capabilities.setCapability("allow-blocked-content", true);
			capabilities.setCapability("allowBlockedContent", true);
			capabilities.setBrowserName(BrowserType.IE);
			capabilities.setCapability("acceptInsecureCerts", false);

			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "\\drivers\\IEDriverServer.exe");
			driver = new InternetExplorerDriver(capabilities);
			driver.get(url);

		} else if (browser.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();

			driver.get(url);
		}
	}

	public static void closeBrowser() { // Function to close a browser
		driver.close();
	}

}
