package com.selenium.Functions;

/*Author:Aparna
 * Aim:Automating add to cart
 * Parameters :User name and Password
 */

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.annotations.AcceptPageFactory;
import com.selenium.annotations.LoginPageFactory;
import com.selenium.annotations.TShirtPageFactory;
import com.selenium.base.Testbase;
import com.selenium.pom.AcceptPolicyPage;
import com.selenium.pom.CartPage;
import com.selenium.pom.HomePage;
import com.selenium.pom.LoginPage;
import com.selenium.pom.MyAccountPage;
import com.selenium.pom.TShirtPage;


public class AddToCart extends Testbase {

	public static void addToCart(String username, String password) {
		AcceptPageFactory acceptPage = PageFactory.initElements(driver, AcceptPageFactory.class);
		wait = new WebDriverWait(driver, 200);
		if(browser.equals("chrome")){
			acceptPage.acceptButton.click();
		}
		element = HomePage.signIn(driver, wait);
		element.click();

		LoginPageFactory loginPage = PageFactory.initElements(driver, LoginPageFactory.class);
		element = loginPage.login_email;
		element.sendKeys(username);
		
		element = loginPage.login_pw;
		element.sendKeys(password);
		
		element = loginPage.submitLogin;
		element.click();

		element = MyAccountPage.itemLink(driver, wait);
		element.click();

		TShirtPageFactory Tshirt=PageFactory.initElements(driver, TShirtPageFactory.class);
		element = Tshirt.addtocart;
		element.click();

		element = CartPage.cartItem_Link(driver, wait);
		if (!element.equals(null)) {
			System.out.println("pass");
		}

	}
/*Method to read user name and password from file*/
	public static String getFromFile(String value) {			
		String data = null;
		try {
			String file = "./src/com/selenium/config/Data.properties";
			FileReader reader = new FileReader(file);

			Properties property = new Properties();

			property.load(reader);

			data = property.getProperty(value);
		} catch (IOException e) {

			e.printStackTrace();
		}

		return data;
	}
}
