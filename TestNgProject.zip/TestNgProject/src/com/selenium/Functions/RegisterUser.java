package com.selenium.Functions;

import java.io.FileOutputStream;
import java.io.IOException;
//Author:Aparna
import java.util.Date;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.selenium.annotations.AcceptPageFactory;
import com.selenium.annotations.HomePageFactory;
import com.selenium.annotations.LoginPageFactory;
import com.selenium.annotations.RegistrationPageFactory;
import com.selenium.base.Testbase;

import com.selenium.pom.AcceptPolicyPage;
import com.selenium.pom.HomePage;
import com.selenium.pom.LoginPage;
import com.selenium.pom.MyAccountPage;
import com.selenium.pom.RegistrationPage;

public class RegisterUser extends Testbase {

	/*
	 * Author:Aparna Aim Automating Registeration page Parameters: userDetails
	 */
	public static void registerUser(String email, String title, String firstName, String lastName, String password,
			String day, String month, String year, String first_name, String last_name, String company, String address1,
			String address2, String city, String state, String zip, String country, String addInfo, String homeNum,
			String mobNum, String addAlias) {

		AcceptPageFactory acceptPage = PageFactory.initElements(driver, AcceptPageFactory.class);

		try {
			if (browser.equals("chrome")) {
				/*
				 * element = AcceptPolicyPage.acceptPolicy_button(driver);
				 * element.click();
				 */
				acceptPage.acceptButton.click();
			}

			wait = new WebDriverWait(driver, 200);
			element = HomePage.signIn(driver, wait); // clicking on the sign
			element.click();

			// wait.until(ExpectedConditions.presenceOfElementLocated((By)
			// homepage.signInLink));
			// homepage.signInLink.click();

			Date date = new Date();
			int d1 = date.getDate();
			long d2 = date.getTime();

			String[] emailId = email.split("@");
			email = emailId[0] + d1 + d2 + "@" + emailId[1]; // unique value for
																// email//
																// generated
			LoginPageFactory loginPage = PageFactory.initElements(driver, LoginPageFactory.class);
			loginPage.txtbx_UserName.sendKeys(email);
			loginPage.createAccount.click();

			// System.out.println(email);
			/*
			 * element = LoginPage.emailBox(driver); element.sendKeys(email);
			 * String mail = element.getAttribute("value");
			 * Assert.assertEquals(email, mail);
			 */
			/*
			 * 
			 */
			/*
			 * element = LoginPage.createAccount_button(driver);
			 * element.click();
			 */

			/*--------Registering user-------*/
			/*
			 * if (title.equals("Mr")) { // checking if title is Mr or Ms
			 * element = RegistrationPage.titleMr_radio(driver, wait);
			 * element.click(); } else { element =
			 * RegistrationPage.titleMrs_radio(driver, wait); element.click(); }
			 * 
			 * element = RegistrationPage.firstNameField(driver); // checking if
			 * // the actual // and expected // value are the // same
			 * element.sendKeys(firstName); String firstname =
			 * element.getAttribute("value"); Assert.assertEquals(firstname,
			 * firstName);
			 * 
			 * element = RegistrationPage.lastNameField(driver); // checking if
			 * the // actual and // expected // value are the // same
			 * element.sendKeys(lastName); String lastname =
			 * element.getAttribute("value"); Assert.assertEquals(lastname,
			 * lastName);
			 * 
			 * element = RegistrationPage.passwordField(driver);
			 * element.sendKeys(password); String pwd =
			 * element.getAttribute("value"); Assert.assertEquals(pwd,
			 * password);
			 * 
			 * int day1 = Integer.parseInt(day); element =
			 * RegistrationPage.daysField(driver); dropdown = new
			 * Select(element); dropdown.selectByIndex(day1);
			 * 
			 * element = RegistrationPage.monthsField(driver); dropdown = new
			 * Select(element); dropdown.selectByVisibleText(month);
			 * 
			 * element = RegistrationPage.yearsField(driver); dropdown = new
			 * Select(element); dropdown.selectByValue(year);
			 * 
			 * element = RegistrationPage.newsLetter_checkBox(driver);
			 * element.click(); element =
			 * RegistrationPage.options_checkBox(driver); element.click();
			 * 
			 * element = RegistrationPage.fname_Field(driver); element.clear();
			 * element.sendKeys(first_name); String fname =
			 * element.getAttribute("value"); Assert.assertEquals(fname,
			 * first_name);
			 * 
			 * element = RegistrationPage.lname_Field(driver); element.clear();
			 * element.sendKeys(last_name); String lname =
			 * element.getAttribute("value"); Assert.assertEquals(lname,
			 * last_name);
			 * 
			 * element = driver.findElement(By.id("company"));
			 * element.sendKeys(company); String companyName =
			 * element.getAttribute("value"); Assert.assertEquals(companyName,
			 * company);
			 * 
			 * element = RegistrationPage.address1_Field(driver);
			 * element.sendKeys(address1); String addressLine1 =
			 * element.getAttribute("value"); Assert.assertEquals(addressLine1,
			 * address1);
			 * 
			 * element = RegistrationPage.address2_Field(driver);
			 * element.sendKeys(address2); String addressLine2 =
			 * element.getAttribute("value"); Assert.assertEquals(addressLine2,
			 * address2);
			 * 
			 * element = RegistrationPage.city_Field(driver);
			 * element.sendKeys(city); String city_value =
			 * element.getAttribute("value"); Assert.assertEquals(city_value,
			 * city);
			 * 
			 * element = RegistrationPage.state_dropdown(driver); dropdown = new
			 * Select(element); dropdown.selectByVisibleText(state); // String
			 * state_value=element.getAttribute("value"); //
			 * Assert.assertEquals(state_value,state);
			 * 
			 * element = RegistrationPage.zip_field(driver);
			 * element.sendKeys(zip); String zipCode =
			 * element.getAttribute("value"); Assert.assertEquals(zipCode, zip);
			 * 
			 * element = RegistrationPage.country_dropdown(driver); dropdown =
			 * new Select(element); dropdown.selectByVisibleText(country);
			 * 
			 * element = RegistrationPage.other_field(driver);
			 * element.sendKeys(addInfo);
			 * 
			 * element = RegistrationPage.homeNum_field(driver);
			 * element.sendKeys(homeNum); String homeContact =
			 * element.getAttribute("value"); Assert.assertEquals(homeContact,
			 * homeNum);
			 * 
			 * element = RegistrationPage.mobNum_field(driver);
			 * element.sendKeys(mobNum); String MobContact =
			 * element.getAttribute("value"); Assert.assertEquals(MobContact,
			 * mobNum);
			 * 
			 * element = RegistrationPage.addressAlias_field(driver);
			 * element.clear(); element.sendKeys(addAlias); String alias =
			 * element.getAttribute("value"); Assert.assertEquals(alias,
			 * addAlias);
			 * 
			 * element = RegistrationPage.submit_button(driver);
			 * element.click();
			 * 
			 * element = MyAccountPage.personalInfo_Link(driver, wait);
			 * 
			 */
			RegistrationPageFactory register = PageFactory.initElements(driver, RegistrationPageFactory.class);
			if (title.equals("Mr")) { // checking if title is Mr or Ms
				element = RegistrationPage.titleMr_radio(driver, wait);
				element.click();
			} else {
				element = RegistrationPage.titleMrs_radio(driver, wait);
				element.click();
			}
			register.customerFirstName.sendKeys(firstName);
			register.customerLastName.sendKeys(lastName);
			register.password.sendKeys(password);

			int day1 = Integer.parseInt(day);
			element = register.days;
			dropdown = new Select(element);
			dropdown.selectByIndex(day1);

			element = register.months;
			dropdown = new Select(element);
			dropdown.selectByVisibleText(month);

			element = register.years;
			dropdown = new Select(element);
			dropdown.selectByValue(year);

			element = register.news;
			element.click();
			element = RegistrationPage.options_checkBox(driver);
			element.click();

			element = register.firstname;
			element.clear();
			element.sendKeys(first_name);
			String fname = element.getAttribute("value");
			Assert.assertEquals(fname, first_name);

			element = register.lastname;
			element.clear();
			element.sendKeys(last_name);
			String lname = element.getAttribute("value");
			Assert.assertEquals(lname, last_name);

			element = register.company;
			element.sendKeys(company);
			String companyName = element.getAttribute("value");
			Assert.assertEquals(companyName, company);

			element = register.address1;
			element.sendKeys(address1);
			String addressLine1 = element.getAttribute("value");
			Assert.assertEquals(addressLine1, address1);

			element = register.address2;
			element.sendKeys(address2);
			String addressLine2 = element.getAttribute("value");
			Assert.assertEquals(addressLine2, address2);

			element = register.city;
			element.sendKeys(city);
			String city_value = element.getAttribute("value");
			Assert.assertEquals(city_value, city);

			element = register.state_id;
			dropdown = new Select(element);
			dropdown.selectByVisibleText(state);
			// String state_value=element.getAttribute("value");
			// Assert.assertEquals(state_value,state);

			element = register.zipcode;
			element.sendKeys(zip);
			String zipCode = element.getAttribute("value");
			Assert.assertEquals(zipCode, zip);

			element = register.country;
			dropdown = new Select(element);
			dropdown.selectByVisibleText(country);

			element = register.addInfo;
			element.sendKeys(addInfo);

			element = register.phone;
			element.sendKeys(homeNum);
			String homeContact = element.getAttribute("value");
			Assert.assertEquals(homeContact, homeNum);

			element = register.mob_phone;
			element.sendKeys(mobNum);
			String MobContact = element.getAttribute("value");
			Assert.assertEquals(MobContact, mobNum);

			element = register.addAlias;
			element.clear();
			element.sendKeys(addAlias);
			String alias = element.getAttribute("value");
			Assert.assertEquals(alias, addAlias);

			element = register.submitAccButton;
			element.click();

			element = MyAccountPage.personalInfo_Link(driver, wait);

			if (!element.equals(null)) { // Checking if the registration is
											// successful

				writeToFile(email, password); // Writing the username and
												// password to file

				fail = false;
				// System.out.println("pass");

			}
		} catch (Exception e) {

		}

	}

	public static void writeToFile(String email, String passWord) throws IOException {

		// FileOutputStream file = new
		// FileOutputStream("./src/com/selenium/config/Data.properties");

		Properties property = new Properties();

		String username = "username" + i;
		String password = "password" + i;
		property.setProperty(username, email);
		property.setProperty(password, passWord);
		i++;
		property.store(file, null);

	}
}