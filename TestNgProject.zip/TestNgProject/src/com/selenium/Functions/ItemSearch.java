package com.selenium.Functions;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.selenium.annotations.AcceptPageFactory;
import com.selenium.annotations.HomePageFactory;
import com.selenium.base.Testbase;

import com.selenium.pom.AcceptPolicyPage;
import com.selenium.pom.HomePage;
import com.selenium.pom.SearchResultPage;

public class ItemSearch extends Testbase {

	public static void itemSearch(String itemName, String testValue) {
		AcceptPageFactory acceptPage = PageFactory.initElements(driver, AcceptPageFactory.class);
		try {
			/*
			 * if(browser.equals("chrome")){ acceptPage.acceptButton.click(); }
			 */
			String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL, Keys.RETURN);
			driver.findElement(By.name("button")).sendKeys(selectLinkOpeninNewTab);

			ArrayList<String> handle = new ArrayList<String>(driver.getWindowHandles());// Return
																						// a
																						// string
																						// of
																						// alphanumeric
																						// window
																						// handle

			driver.switchTo().window(handle.get(1));

			wait = new WebDriverWait(driver, 200);
			element = HomePage.searchField(driver, wait);
			element.sendKeys(itemName);
			String searchItem = element.getAttribute("value");
			Assert.assertEquals(itemName, searchItem);

			HomePageFactory homepage = PageFactory.initElements(driver, HomePageFactory.class);

			element = homepage.submitSearch_button;
			element.click();
			element = SearchResultPage.topSellers_Link(driver);

			if (!element.equals(null)) {
				// System.out.println("pass");
				fail = false;
				
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public static void divisionWithException() {
		int i = 1 / 0;
	}

}
