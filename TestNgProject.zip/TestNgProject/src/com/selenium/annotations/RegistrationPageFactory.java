package com.selenium.annotations;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPageFactory {

	final WebDriver driver;

	public RegistrationPageFactory(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(how=How.ID,using="id_gender1")
	public  WebElement gender1;
	
	@FindBy(how=How.ID,using="id_gender2")
	public  WebElement gender2;
	
	@FindBy(how=How.ID,using="customer_firstname")
	public WebElement customerFirstName;
	
	@FindBy(how=How.ID,using="customer_lastname")
	public  WebElement customerLastName;
	
	@FindBy(how=How.ID,using="passwd")
	public  WebElement password;
	
	@FindBy(how=How.ID,using="days")
	public  WebElement days;
	
	@FindBy(how=How.ID,using="months")
	public  WebElement months;
	
	@FindBy(how=How.ID,using="years")
	public  WebElement years;

	@FindBy(how=How.ID,using="newsletter")
	public  WebElement news;
	
	@FindBy(how=How.ID,using="optin")
	public  WebElement option;
	
	@FindBy(how=How.ID,using="firstname")
	public  WebElement firstname;
	
	@FindBy(how=How.ID,using="lastname")
	public  WebElement lastname;
	
	
	@FindBy(how=How.ID,using="company")
	public  WebElement company;
	
	@FindBy(how=How.ID,using="address1")
	public  WebElement address1;
	
	@FindBy(how=How.ID,using="address2")
	public  WebElement address2;
	
	@FindBy(how=How.ID,using="city")
	public  WebElement city;
	
	@FindBy(how=How.ID,using="id_state")
	public  WebElement state_id;
	
	@FindBy(how=How.ID,using="postcode")
	public  WebElement zipcode;
	
	@FindBy(how=How.ID,using="id_country")
	public  WebElement country;
	
	@FindBy(how=How.ID,using="other")
	public  WebElement addInfo;
	
	@FindBy(how=How.ID,using="phone")
	public  WebElement phone;
	
	@FindBy(how=How.ID,using="phone_mobile")
	public  WebElement mob_phone;
	
	@FindBy(how=How.ID,using="alias")
	public  WebElement addAlias;
	
	@FindBy(how=How.ID,using="submitAccount")
	public  WebElement submitAccButton;
}
