package com.selenium.annotations;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class HomePageFactory {

	final WebDriver driver;

	public HomePageFactory(WebDriver driver) {
		this.driver = driver;
	}
	
	@FindBy(how=How.LINK_TEXT,using="Sign in")
	public static WebElement signInLink;
	
	@FindBy(how=How.NAME,using="submit_search")
	public  WebElement submitSearch_button;
	
}
