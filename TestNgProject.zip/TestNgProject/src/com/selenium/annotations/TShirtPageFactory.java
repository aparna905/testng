package com.selenium.annotations;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class TShirtPageFactory {
	final WebDriver driver;

	public TShirtPageFactory(WebDriver driver) {
	
		this.driver = driver;
	}
	
	@FindBy(how=How.LINK_TEXT,using="Add to cart")
	public static WebElement addtocart;

}
