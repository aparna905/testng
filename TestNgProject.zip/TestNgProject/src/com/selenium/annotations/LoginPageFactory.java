package com.selenium.annotations;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;



public class LoginPageFactory {
	
	final WebDriver driver;
	
	
	public LoginPageFactory(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(how=How.ID,using="email_create")
	public WebElement txtbx_UserName;
	
	
	@FindBy(how=How.ID,using="SubmitCreate")
	public WebElement createAccount;
	
	@FindBy(how=How.ID,using="email")
	public WebElement login_email;
	
	@FindBy(how=How.ID,using="passwd")
	public WebElement login_pw;


	@FindBy(how=How.ID,using="SubmitLogin")
	public WebElement submitLogin;

}
