package com.selenium.script;

import java.io.IOException;

import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selenium.Functions.Connection;
import com.selenium.Functions.ItemSearch;
import com.selenium.base.Testbase;
import com.selenium.util.TestUtil;

/*Author:Aparna
 * Aim:Script for validating a search Item
 * Parameters : Url,Browser name,Item to be searched
 */

//@Listeners(com.selenium.listener.ListenerTest.class)
public class Searchitems extends Testbase {

	public static boolean skip = false;
	public static boolean isTestPass = false;
	public static int count = -1;

	@Parameters({ "url", "browser" })
	@BeforeTest(alwaysRun = true)
	public void checkSkipTest(String url, String browser) { // Checking if test
															// case is scheduled
															// as yes
		initialize();
		Testbase.url = url;
		Testbase.browser = browser;
		if (!TestUtil.isTestCaseRunnable(suiteAxls, this.getClass().getSimpleName())) {
			skip = true;
			throw new SkipException(
					"This testcase " + this.getClass().getSimpleName() + "has been skipped as scheduled is NO");
		}
	}

	@Test(priority=1,enabled=true,/* groups={"Platinum"}, */dataProvider = "searchItemData"/*, expectedExceptions = ArithmeticException.class*/) // Test
																														// method()
	public void searchItemMethod(String itemName, String testValue) {

		Connection.openBrowser(url);
		//ItemSearch.divisionWithException(); 			// Checking Expected Exception
		System.out.println("priority1");
		
		ItemSearch.itemSearch(itemName, testValue);
		Connection.closeBrowser();
		isTestPass = true;

	}

	@DataProvider // Data taken from excel sheet and passed as an object
	public Object[][] searchItemData() {
		return (TestUtil.getData(suiteAxls, this.getClass().getSimpleName()));
	}

	@AfterMethod
	public void resultAfterTestCase() { // Writing the result after the test
		if (skip) {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "SKIP");
			rowcount++;
		} else if (fail) {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "FAIL");
			rowcount++;
			isTestPass = false;
		} else {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "PASS");
			rowcount++;
		}

		skip = false;
		fail = false;
		driver.quit();
	}

	@AfterTest
	public void resultAfterTest() { // Writing the result after the test
		if (isTestPass) {
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "PASS");
		} else {
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "FAIL");
		}
	}

	@Test(priority=0,enabled=true)							//Priority is set to 0 and is run first
	public void Test2(){
		Connection.openBrowser(url);
		System.out.println("priority0");
		Connection.closeBrowser();
	}
	
	@Test(priority=2,enabled=true)						//priority set to 2
	public void Test3(){
		Connection.openBrowser(url);
		System.out.println("priority2");
		Connection.closeBrowser();
		
	}
	@Test(priority=3,enabled=true)
	public void Test4(){
		Connection.openBrowser(url);
		System.out.println("priority3");
		Connection.closeBrowser();
		
	}
}
