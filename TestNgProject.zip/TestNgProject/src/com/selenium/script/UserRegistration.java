package com.selenium.script;

import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selenium.Functions.AddToCart;
import com.selenium.Functions.Connection;
import com.selenium.Functions.RegisterUser;
import com.selenium.base.Testbase;
import com.selenium.util.TestUtil;

/*Author:Aparna
 * Aim:Script for registering a user
 * Parameters : url,Browser name,user details
 */

public class UserRegistration extends Testbase {
	public static boolean skip = false;
	public static boolean isTestPass = false;
	public static int count = -1;

	@Parameters({ "url", "browser" })
	@BeforeTest(alwaysRun = true)
	public void checkSkipTest(String url, String browser) { // Checking if test
															// case is scheduled
															// as yes
		initialize();
		Testbase.url = url;
		Testbase.browser = browser;
		if (!TestUtil.isTestCaseRunnable(suiteAxls, this.getClass().getSimpleName())) {
			skip = true;
			throw new SkipException(
					"This testcase " + this.getClass().getSimpleName() + "has been skipped as scheduled is NO");
		}
	}

	@Test(priority=1,enabled=true,/* groups={"Silver"} */dataProvider = "userRegistrationData" /*retryAnalyzer = Retry.class*/) // Test
																										// method()
	public void userRegistrationMethod(String email, String title, String firstName, String lastName, String password,
			String day, String month, String year, String first_name, String last_name, String company, String address1,
			String address2, String city, String state, String zip, String country, String addInfo, String homeNum,
			String mobNum, String addAlias) {

		
			Connection.openBrowser(url);
			//Assert.assertEquals(false, true);
			RegisterUser.registerUser(email, title, firstName, lastName, password, day, month, year, first_name,
					last_name, company, address1, address2, city, state, zip, country, addInfo, homeNum, mobNum,
					addAlias);
			Connection.closeBrowser();

			isTestPass = true;
	}

	@DataProvider
	public Object[][] userRegistrationData() { // Data taken from excel sheet
												// and passed as an object
		return (TestUtil.getData(suiteAxls, this.getClass().getSimpleName()));
	}

	@AfterMethod
	public void resultAfterTestCase() { // Writing the result after the test
		if (skip) {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "SKIP");
			rowcount++;
		} else if (fail) {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "FAIL");
			rowcount++;
			isTestPass = false;
		} else {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "PASS");
			rowcount++;
		}

		skip = false;
		fail = false;
		driver.quit();
	}

	@AfterTest
	public void resultAfterTest() { // Writing the result after the test
		if (isTestPass) {
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "PASS");
		} else {
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "FAIL");
		}
	}

	/* test method that depends on another test method userRegistration */

	@Test(priority=2,dependsOnMethods = "userRegistrationMethod",enabled=true)
	public void addItemsMethod() {
	
			Connection.openBrowser(url);
			String username = AddToCart.getFromFile("username1");
			String password = AddToCart.getFromFile("password1");
			AddToCart.addToCart(username, password);

	
	}

}
